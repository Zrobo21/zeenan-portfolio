"""
Automatic blog post generator with a self-review / correction pass.

What this does:
1. Reads the next unused keyword from scripts/keywords.txt
2. Sends a detailed SEO + humanization prompt to Google Gemini (free tier) -> DRAFT
3. Sends the draft back to Gemini as an independent EDITOR pass that scores it
   against the same rules and rewrites any part that fails (banned phrases,
   weak SEO structure, generic filler, missing FAQ, etc.)
4. Parses the corrected version into a Jekyll-ready Markdown post
5. Saves it into _posts/ with today's date, and logs the editor's notes into
   _data/review_log.yml so you can see what was fixed on every run
6. Removes the used keyword from keywords.txt so it's never repeated

This is the "self-learning" mechanism in honest terms: there is no model
training happening, and nothing here modifies the website's code or behavior
on its own. What actually happens is a second, independent AI pass that
checks the first draft against your rules and fixes what fails -- a real,
safe quality-control loop, run fresh on every post.

Runs automatically via .github/workflows/auto-blog.yml on a schedule.
Requires a GEMINI_API_KEY secret set in the GitHub repo (Settings > Secrets > Actions).
"""

import os
import re
import sys
import json
import datetime
import urllib.request
import urllib.error

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
GEMINI_MODEL = "gemini-2.0-flash"
GEMINI_URL = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent?key={GEMINI_API_KEY}"

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KEYWORDS_FILE = os.path.join(REPO_ROOT, "scripts", "keywords.txt")
POSTS_DIR = os.path.join(REPO_ROOT, "_posts")
REVIEW_LOG = os.path.join(REPO_ROOT, "_data", "review_log.yml")

SITE_CONTEXT = """
You are writing for a personal brand website belonging to Haa Meem Ul Karim Zeenan (goes by Zeenan),
a Dhaka, Bangladesh-based digital marketing consultant. He holds an NSDA Level 3 Digital Marketing
certification. His audience is a mix of:
1. People researching digital marketing / SEO topics to learn the skill themselves.
2. Bangladeshi small and medium business owners who need practical marketing advice.

Tone: conversational, confident, practical — like an experienced consultant talking to a smart friend,
not a corporate blog. Bangladesh-aware where relevant (local market examples, BDT pricing context,
Bangla-English code-switching habits of local searchers) but written in English.
"""

PROMPT_TEMPLATE = """{site_context}

Write a complete, publish-ready, SEO-optimized blog article targeting the primary keyword: "{keyword}"

Follow these rules strictly:

SEO RULES:
- Primary keyword in the title, first 100 words, at least one H2, and naturally 3-5 more times in the body (never forced, density roughly 0.5-1.5%).
- Use clear H2/H3 hierarchy (as Markdown ## and ###).
- Short paragraphs (2-4 sentences).
- Include a natural FAQ section near the end with 3-4 real people-also-ask style questions, each answered in 2-4 sentences.
- Readability should sit around grade 7-9 — clear and accessible, not academic.

HUMANIZATION RULES (very important):
- Vary sentence length and structure. Mix short punchy sentences with longer explanatory ones.
- NEVER use these phrases or anything close to them: "in today's fast-paced world", "in conclusion",
  "unlock the power of", "delve into", "it's important to note", "when it comes to",
  "at the end of the day", "game-changer", "landscape" (as a metaphor), excessive em-dashes,
  or stacked "moreover/furthermore" transitions.
- Take a clear point of view. Disagree with a common misconception in the space if genuinely true.
  Do not write a neutral, hedge-everything summary.
- No robotic "on one hand / on the other hand" symmetry. No listicle padding like "last but not least".
- Do not fabricate statistics or studies. If a specific number would help, write "[verify/insert data]" instead.

OUTPUT FORMAT (strict):
Return ONLY valid JSON, no markdown code fences, no preamble, in exactly this shape:

{{
  "title": "SEO-friendly title, under 60 characters if possible",
  "meta_description": "under 155 characters, written to earn the click",
  "tags": ["2 to 4 short tags"],
  "body_markdown": "the full article body in Markdown, starting from the first paragraph (do not repeat the title as an H1 inside the body)"
}}
"""

EDITOR_PROMPT_TEMPLATE = """You are a strict SEO and content editor reviewing a draft blog post before publish.
The draft targets the primary keyword: "{keyword}"

Check the draft below against ALL of these rules:
1. Primary keyword present in title, first 100 words, at least one H2, and 3-5 times total in body (not stuffed).
2. Clear H2/H3 hierarchy, short paragraphs (2-4 sentences).
3. Contains an FAQ section with 3-4 real questions, each answered in 2-4 sentences.
4. Does NOT contain any of these banned phrases or close equivalents: "in today's fast-paced world",
   "in conclusion", "unlock the power of", "delve into", "it's important to note", "when it comes to",
   "at the end of the day", "game-changer", "landscape" (as metaphor), stacked moreover/furthermore.
5. Sentence rhythm is varied (not repetitive length/structure). Has a clear point of view, not generic
   hedge-everything summary tone. No robotic "on one hand/other hand" symmetry, no listicle padding.
6. No fabricated statistics presented as fact (should say "[verify/insert data]" if a number is needed
   but not verified).
7. Readability roughly grade 7-9.

DRAFT TITLE: {title}
DRAFT BODY:
{body}

If the draft already passes every rule cleanly, return it unchanged.
If anything fails, rewrite ONLY the parts that fail (keep what already works) and produce a corrected
full version.

Return ONLY valid JSON, no markdown code fences, no preamble, in exactly this shape:

{{
  "passed_initial_check": true or false,
  "issues_found": ["short description of each issue found, empty array if none"],
  "final_title": "the title, corrected if needed",
  "final_body_markdown": "the full corrected article body in Markdown"
}}
"""


def load_keywords():
    if not os.path.exists(KEYWORDS_FILE):
        print(f"No keywords file found at {KEYWORDS_FILE}")
        sys.exit(1)
    with open(KEYWORDS_FILE, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f.readlines()]
    return [line for line in lines if line]


def save_remaining_keywords(remaining):
    with open(KEYWORDS_FILE, "w", encoding="utf-8") as f:
        for kw in remaining:
            f.write(kw + "\n")


def call_gemini(prompt):
    if not GEMINI_API_KEY:
        print("ERROR: GEMINI_API_KEY environment variable is not set.")
        sys.exit(1)

    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "temperature": 0.9,
            "maxOutputTokens": 4096,
        },
    }

    req = urllib.request.Request(
        GEMINI_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=90) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        print("Gemini API error:", e.code, e.read().decode("utf-8"))
        sys.exit(1)

    try:
        text = data["candidates"][0]["content"]["parts"][0]["text"]
    except (KeyError, IndexError):
        print("Unexpected Gemini response shape:", json.dumps(data)[:1000])
        sys.exit(1)

    return text


def extract_json(text):
    # Strip markdown code fences if the model added them anyway.
    text = text.strip()
    text = re.sub(r"^```(json)?", "", text).strip()
    text = re.sub(r"```$", "", text).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # Try to find the first { ... last } block as a fallback.
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1:
            return json.loads(text[start:end + 1])
        raise


def run_editor_pass(keyword, title, body):
    """Sends the draft to a second, independent Gemini call acting as an editor.
    Returns (final_title, final_body, issues_found_list)."""
    prompt = EDITOR_PROMPT_TEMPLATE.format(keyword=keyword, title=title, body=body)
    raw = call_gemini(prompt)
    try:
        result = extract_json(raw)
    except (json.JSONDecodeError, ValueError):
        # If the editor pass fails to parse, fall back to the original draft
        # rather than breaking the whole run.
        print("Editor pass returned unparseable output — keeping original draft.")
        return title, body, ["editor pass failed to parse, original draft kept"]

    final_title = result.get("final_title", title).strip()
    final_body = result.get("final_body_markdown", body).strip()
    issues = result.get("issues_found", [])
    return final_title, final_body, issues


def log_review(keyword, issues, filename):
    os.makedirs(os.path.dirname(REVIEW_LOG), exist_ok=True)
    entry_lines = [
        f'- date: "{datetime.date.today().isoformat()}"',
        f'  keyword: "{keyword}"',
        f'  file: "{filename}"',
        f'  issues_found: {len(issues)}',
    ]
    if issues:
        entry_lines.append("  notes:")
        for issue in issues:
            safe = str(issue).replace('"', "'")
            entry_lines.append(f'    - "{safe}"')
    else:
        entry_lines.append("  notes: []")

    existing = ""
    if os.path.exists(REVIEW_LOG):
        with open(REVIEW_LOG, "r", encoding="utf-8") as f:
            existing = f.read()

    with open(REVIEW_LOG, "w", encoding="utf-8") as f:
        f.write(existing + "\n".join(entry_lines) + "\n")


def slugify(title):
    slug = title.lower()
    slug = re.sub(r"[^a-z0-9\s-]", "", slug)
    slug = re.sub(r"\s+", "-", slug).strip("-")
    return slug[:70]


def main():
    keywords = load_keywords()
    if not keywords:
        print("No keywords left in keywords.txt — add more before the next run.")
        sys.exit(0)

    keyword = keywords[0]
    remaining = keywords[1:]

    print(f"Generating post for keyword: {keyword}")
    prompt = PROMPT_TEMPLATE.format(site_context=SITE_CONTEXT, keyword=keyword)
    raw = call_gemini(prompt)
    post = extract_json(raw)

    draft_title = post["title"].strip()
    meta_description = post.get("meta_description", "").strip()
    tags = post.get("tags", [])
    draft_body = post["body_markdown"].strip()

    print("Running editor / self-correction pass...")
    title, body, issues = run_editor_pass(keyword, draft_title, draft_body)
    if issues:
        print(f"Editor found and fixed {len(issues)} issue(s): {issues}")
    else:
        print("Editor pass: draft already met all rules.")

    today = datetime.date.today().isoformat()
    slug = slugify(title)
    filename = f"{today}-{slug}.md"
    filepath = os.path.join(POSTS_DIR, filename)

    front_matter_tags = ", ".join(f'"{t}"' for t in tags)
    front_matter = (
        "---\n"
        f'title: "{title.replace(chr(34), chr(39))}"\n'
        f"date: {today}\n"
        f"description: \"{meta_description.replace(chr(34), chr(39))}\"\n"
        f"tags: [{front_matter_tags}]\n"
        "---\n\n"
    )

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(front_matter + body + "\n")

    print(f"Wrote new post: {filepath}")

    log_review(keyword, issues, filename)

    save_remaining_keywords(remaining)
    print(f"{len(remaining)} keyword(s) left in queue.")


if __name__ == "__main__":
    main()
